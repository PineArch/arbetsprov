﻿((window, document) => {
    // variabler
    const query = document.getElementById("query"),
        searchBtn = document.getElementById("search-btn"),
        searchResult = document.getElementById("result");

    // lyssnare
    searchBtn.addEventListener("click", (e) => {
        apiFetch(query.value);
    });

    query.addEventListener("keyup", (e) => {
        if (e.keyCode == 13) {
            apiFetch(e.target.value);
        }
    })

    // funktioner
    const apiFetch = query => {
        fetch(`/api/search?query=${query}`)
            .then(response => response.json())
            .then(
                result => {
                    setList(result);
                }, error => {
                    console.log(error);
                }
            );
    }

    const setList = list => {
        let record = "";

        if (list.length > 0) {
            list.forEach((e, i) => {
                record += `
                    <div class="record">
                        <div class="record-title">
                            ${e.isbn.length > 0 ?
                            `<a href="http://libris.kb.se/bib/${e.url}" target="_blank" rel="noopener noreferrer">${e.title}</a>` :
                            e.title}
                        </div>
                        <div>
                            <span class="fat">Författare:</span> ${e.author ? e.author : "--"}
                        </div>
                        <div>
                            <span class="fat">ISBN:</span> ${e.isbn.length > 0 ? e.isbn.join(", ") : "--"}
                        </div>
                    </div>
                `;
            });
        } else {
            record = `<div>Inga träffar</div>`;
        }

        searchResult.innerHTML = record;
    }
})(this, document);
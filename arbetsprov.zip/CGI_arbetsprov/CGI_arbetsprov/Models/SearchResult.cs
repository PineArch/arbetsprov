﻿using System.Collections.Generic;
using System.Linq;
using System.Xml.Linq;

namespace CGI_arbetsprov.Models {

    public static class SearchResult {
        public static List<Record> GetRecords(XElement resultList, XNamespace ns) {
            var records = resultList.Descendants(ns + "record");
            List<Record> recordList = new List<Record>();

            foreach (var r in records) {
                Record record = new Record();

                foreach (var e in r.Elements()) {
                    //URL
                    if (e.HasAttributes && e.Attribute("tag").Value == "001") {
                        record.URL = e.Value;
                    }

                    //ISBN
                    if (e.HasAttributes && e.Attribute("tag").Value == "020") {
                        var isbn = e.Elements().Where(x => x.Attribute("code").Value == "a");
                        if (isbn.Count() > 0) record.ISBN.Add(isbn.First().Value);
                    }

                    //Titel
                    if (e.HasAttributes && e.Attribute("tag").Value == "245") {
                        var title = e.Elements().Where(x => x.Attribute("code").Value == "a");
                        if (title.Count() > 0) record.Title = title.First().Value;
                    }

                    //Författare
                    if (e.HasAttributes && e.Attribute("tag").Value == "100") {
                        var author = e.Elements().Where(x => x.Attribute("code").Value == "a");
                        if (author.Count() > 0) record.Author = author.First().Value;
                    }
                }

                recordList.Add(record);
            }

            return recordList;
        }
    }

    public class Record {
        public List<string> ISBN { get; set; }
        public string Author { get; set; }
        public string Title { get; set; }
        public string URL { get; set; }

        public Record() {
            ISBN = new List<string>();
        }
    }
}

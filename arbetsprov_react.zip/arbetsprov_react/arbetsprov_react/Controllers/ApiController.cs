﻿using System.IO;
using System.Net.Http;
using System.Threading.Tasks;
using System.Xml.Linq;
using Microsoft.AspNetCore.Mvc;

// For more information on enabling MVC for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace arbetsprov_react.Controllers {

    [ApiController]
    public class ApiController : Controller {

        private readonly IHttpClientFactory _clientFactory;

        public ApiController(IHttpClientFactory clientFactory) {
            _clientFactory = clientFactory;
        }

        [HttpGet]
        [Route("api/search")]
        public async Task<IActionResult> Search(string query) {
            string apiString = $"http://api.libris.kb.se/xsearch?query={query}";
            var request = new HttpRequestMessage(HttpMethod.Get, apiString);
            var response = await _clientFactory.CreateClient().SendAsync(request, HttpCompletionOption.ResponseHeadersRead);

            using (Stream stream = await response.Content.ReadAsStreamAsync()) {
                response.EnsureSuccessStatusCode();
                XElement resultList = XElement.Load(stream);
                XNamespace ns = "http://www.loc.gov/MARC21/slim";

                return Json(SearchResult.GetRecords(resultList, ns));
            }
        }
    }
}

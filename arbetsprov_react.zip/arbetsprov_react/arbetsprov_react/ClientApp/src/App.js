import React from 'react';
import Main from "./components/Main";

import './custom.css'

export default function App() {

    return (
        <Main />
    );
}

﻿import React from "react";

function Search(props) {

    const handleEnterClick = (e) => {
        if (e.keyCode === 13) {
            props.setQuery(e.target.value);
        }
    }

    const handleClick = (e) => {
        const query = document.getElementById("query").value;
        props.setQuery(query);
    }

    return (
        <div className="search-container">
            <input type="search" id="query" placeholder="Ställ din sökfråga här..." onKeyUp={handleEnterClick} />
            <button onClick={handleClick}>Sök</button>
        </div>
    );
}

export default Search;
﻿import React from "react";

function Record(props) {
    return (
        <div className="record">
            <div className="record-title">{props.data.isbn.length > 0 ? 
                <a href={`http://libris.kb.se/bib/${props.data.url}`} target="_blank" rel="noopener noreferrer">{props.data.title}</a> :
                props.data.title}
            </div>
            <div>
                <span className="fat">Författare</span>: {props.data.author ? props.data.author : "--"}
            </div>
            <div>
                <span className="fat">ISBN</span>: {props.data.isbn.length > 0 ? props.data.isbn.join(", ") : "--"}
            </div>
        </div>
    );
}

export default Record;
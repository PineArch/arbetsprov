﻿import React, { useState, useEffect } from "react";
import Search from "./Search";
import RecordList from "./RecordList";

const useFetch = (query) => {
    const [data, setData] = useState([]);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState(false);

    useEffect(() => {
        if (query) {
            setLoading(true);
            setError(false);
            fetch(`/api/search?query=${query}`)
                .then(response => response.json())
                .then(
                    result => {
                        setData(result);
                        setLoading(false);
                    }, error => {
                        console.log(error);
                        setError(true);
                        setLoading(false);
                    }
                );
        }
    }, [query]);

    return [data, loading, error];
}

function Main() {
    const [query, setQuery] = useState(undefined);
    const [data, loading, error] = useFetch(query);

    return (
        <div className="main">
            <Search setQuery={setQuery} />
            {error && <div>Ett fel inträffade</div>}
            {loading ? <div>laddar...</div> :
                data.length > 0 ? <RecordList data={data} /> :
                    !query && <div></div>}
        </div>
    );
}

export default Main;
﻿import React from "react";
import Record from "./Record";

function RecordList(props) {
    return (
        <div className="record-list">
            {props.data.map((e, i) => <Record key={i} data={e} />)}
        </div>
    );
}

export default RecordList;